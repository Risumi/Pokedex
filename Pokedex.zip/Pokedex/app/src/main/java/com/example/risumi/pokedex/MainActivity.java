package com.example.risumi.pokedex;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;

import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity  {

    RecyclerView mRecyclerView;
    PokemonAdapter mAdapter;
    String url, mJson;
    ArrayList<Pokemon> listPokemon;
    Button intentButton;
    EditText searchText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listPokemon = new ArrayList<>();
//        listPokemon.add(new Pokemon("Bulbasaur","Grass"));
//        listPokemon.add(new Pokemon("Squirtle","Water"));
//        listPokemon.add(new Pokemon("Charmander","Fire"));
        mRecyclerView = findViewById(R.id.Rescycler);
        mAdapter = new PokemonAdapter(this, listPokemon);
        mRecyclerView.setAdapter(mAdapter);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
//        intentButton = findViewById(R.id.IntentButton);
//        intentButton.setOnClickListener(this);
        searchText = findViewById(R.id.searchText);
        searchText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                filter(s.toString());
            }
        });
        new GetDataSync().execute();
    }

    void filter(String text){
        ArrayList filteredPokemon = new ArrayList<>();
        for (Pokemon s : listPokemon){
            if (s.name.toLowerCase().contains(text.toLowerCase())){
                filteredPokemon.add(s);
            }
        }
        mAdapter.filterList(filteredPokemon);
    }

    public class GetDataSync extends AsyncTask<Void, Void, Void> {
        ProgressDialog dialog;
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            dialog = new ProgressDialog(MainActivity.this);
            dialog.setMessage("Loading...");
            dialog.show();
            dialog.setCancelable(false);
        }

        @Override
        protected Void doInBackground(Void... params) {
            try {
                getData();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            dialog.cancel();
//            txtUser.setText(mJson);
        }
    }
    JSONObject jsonPokemon, pokemonRegion ,jsonTypes,jsonType;
    JSONArray pokemonTypes;
    String pokemonName,pokemonType, imageURL;
    private void getData() throws IOException, JSONException {
        pokemonRegion = readJsonFromUrl("https://pokeapi.co/api/v2/pokedex/kanto/");
        JSONArray jsonArray= pokemonRegion.getJSONArray("pokemon_entries");
        int len = jsonArray.length();
        try {
            for (int i=0;i<10;i++){
                jsonPokemon = readJsonFromUrl("https://pokeapi.co/api/v2/pokemon/"+(i+1)+"/");
                pokemonName = jsonPokemon.getString("name");
                pokemonTypes = jsonPokemon.getJSONArray("types");
                jsonTypes = pokemonTypes.getJSONObject(0);
                jsonType = jsonTypes.getJSONObject("type");
                pokemonType = jsonType.getString("name");
                imageURL = "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/"+(i+1)+".png";
                listPokemon.add(new Pokemon(pokemonName,pokemonType,imageURL));
                Log.d("Pokemon",pokemonName);
            }
            synchronized (mAdapter){
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        mAdapter.notifyDataSetChanged();
                    }
                });

            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private String readAll(Reader rd) throws IOException {
        StringBuilder sb = new StringBuilder();
        int cp;
        while ((cp = rd.read()) != -1) {
            sb.append((char) cp);
        }
        return sb.toString();
    }

    public JSONObject readJsonFromUrl(String url) throws IOException, JSONException {
        InputStream is = new URL(url).openStream();
        try {
            BufferedReader rd = new BufferedReader(new InputStreamReader(is, Charset.forName("UTF-8")));
            String jsonText = readAll(rd);
            JSONObject json = new JSONObject(jsonText);
            return json;
        } finally {
            is.close();
        }
    }
}
