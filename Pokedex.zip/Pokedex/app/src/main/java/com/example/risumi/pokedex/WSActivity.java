package com.example.risumi.pokedex;

import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.ArrayList;

public class WSActivity extends AppCompatActivity implements View.OnClickListener{
    String url = "192.168.1.7";
    EditText ipText;
    Button btn;
    ArrayList<WS> listWS;
    RecyclerView mRecyclerView;
    WSAdapter mAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ws);
        ipText = findViewById(R.id.ipText);
        ipText.setText(url);
        btn  =findViewById(R.id.buttonA);
        btn.setOnClickListener(this);
        listWS = new ArrayList<>();
        mRecyclerView = findViewById(R.id.Rescycler);
        mAdapter = new WSAdapter(this, listWS);
        mRecyclerView.setAdapter(mAdapter);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        new GetDataSync().execute();
    }

    @Override
    public void onClick(View v) {
        url = ipText.getText().toString();
        new GetDataSync().execute();
    }

    public class GetDataSync extends AsyncTask<Void, Void, Void> {
        ProgressDialog dialog;
        @Override
        protected void onPreExecute () {
            super.onPreExecute();
            dialog = new ProgressDialog(WSActivity.this);
            dialog.setMessage("Loading...");
            dialog.show();
            dialog.setCancelable(false);
        }

        @Override
        protected Void doInBackground(Void... params) {
            try {
                getData();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            dialog.cancel();
//            txtUser.setText(mJson);
        }
    }
    JSONObject jsonNum,jsonData;

    String idbuku, judulbuku, username, tglpinjam, tglkembali;
    private void getData() throws IOException, JSONException {
        jsonNum= readJsonFromUrl("http://api.openweathermap.org/data/2.5/weather?q="+kota+"&APPID=000c9b069f220b52aa5d885b50e45837");
        jsonData= jsonNum.getJSONObject("0");
        try {
            for (int i=0;i<jsonNum.length();i++){
                jsonData= jsonNum.getJSONObject(Integer.toString(i));
                idbuku = jsonData.getString("id_buku");
                judulbuku = jsonData.getString("judul_buku");
                username = jsonData.getString("username");
                tglpinjam = jsonData.getString("tgl_pinjam");
                tglkembali = jsonData.getString("tgl_kembali");
                listWS.add(new WS(username,judulbuku,tglpinjam,tglkembali));
            }
//            synchronized (mAdapter){
//                runOnUiThread(new Runnable() {
//                    @Override
//                    public void run() {
//                        mAdapter.notifyDataSetChanged();
//                    }
//                });
//
//            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private String readAll(Reader rd) throws IOException {
        StringBuilder sb = new StringBuilder();
        int cp;
        while ((cp = rd.read()) != -1) {
            sb.append((char) cp);
        }
        return sb.toString();
    }

    public JSONObject readJsonFromUrl(String url) throws IOException, JSONException {
        InputStream is = new URL(url).openStream();
        try {
            BufferedReader rd = new BufferedReader(new InputStreamReader(is, Charset.forName("UTF-8")));
            String jsonText = readAll(rd);
            JSONObject json = new JSONObject(jsonText);
            return json;
        } finally {
            is.close();
        }
    }
}
