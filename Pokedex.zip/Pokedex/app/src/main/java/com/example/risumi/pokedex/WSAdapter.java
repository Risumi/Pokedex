package com.example.risumi.pokedex;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class WSAdapter extends RecyclerView.Adapter<WSAdapter.WSViewHolder> {

    LayoutInflater mInflater;
    ArrayList<WS> wsArrayList;
    Context _context;
    WS current;


    public WSAdapter(Context _context, ArrayList<WS> wsArrayList ) {
        this.mInflater = LayoutInflater.from(_context);
        this.wsArrayList = wsArrayList;
        this._context = _context;
    }


    class WSViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener{
        TextView Username;
        TextView Buku;
        TextView TglPinjam;
        TextView TglKembali;
        WSAdapter mAdapter;

        public WSViewHolder(View itemView, WSAdapter adapter) {
            super(itemView);
            Username = itemView.findViewById(R.id.Username);
            Buku = itemView.findViewById(R.id.Buku);
            TglPinjam = itemView.findViewById(R.id.TglPinjam);
            TglKembali = itemView.findViewById(R.id.TglKembali);
            itemView.setOnClickListener(this);
            this.mAdapter = adapter;
        }

        @Override
        public void onClick(View view) {
//            Intent PokeIntent = new Intent(_context, PokemonInfo.class);
//            Bundle bundle = new Bundle();
//            PokeIntent.putExtra("nama",PokemonName.getText().toString());
//            _context.startActivities(new Intent[]{PokeIntent});
            Intent intent = new Intent(_context, MainActivity.class);
            _context.startActivity(intent);
            Log.d("click","yay !");
        }
    }

    @Override
    public WSViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = mInflater.inflate(R.layout.card_ws,parent,false);
        return new WSViewHolder(itemView,this);
    }

    @Override
    public void onBindViewHolder(WSViewHolder holder, int position) {
        current= wsArrayList.get(position);
        //        holder.PokemonImage.setImageResource(current.image);
//        Picasso.get().load(current.imageURL).into(holder.PokemonImage);
        holder.Username.setText(current.username);
        holder.Buku.setText(current.buku);
        holder.TglPinjam.setText(current.tglpinjam);
        holder.TglKembali.setText(current.tglkembali);
//        if(current.type.equalsIgnoreCase("Grass")){
//            holder.PokemonType.setTextColor(Color.GREEN);
//        }else if (current.type.equalsIgnoreCase("Water")){
//            holder.PokemonType.setTextColor(Color.BLUE);
//        }else if (current.type.equalsIgnoreCase("Fire")){
//            holder.PokemonType.setTextColor(Color.RED);
//        }
    }


    @Override
    public int getItemCount() {
        return wsArrayList.size();
    }
}
