package com.example.risumi.pokedex;

public class WS {
    String username, buku, tglpinjam,tglkembali;

    public WS(String username, String buku, String tglpinjam, String tglkembali) {
        this.username = username;
        this.buku = buku;
        this.tglpinjam = tglpinjam;
        this.tglkembali = tglkembali;
    }
}
