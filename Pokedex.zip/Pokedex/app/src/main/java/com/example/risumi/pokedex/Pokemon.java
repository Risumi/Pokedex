package com.example.risumi.pokedex;

public class Pokemon {
    String name;
    String type;
    String imageURL;
//    int image;

    public Pokemon(String name, String type, String imageURL) {
        this.name = name;
        this.type = type;
        this.imageURL = imageURL;
//        this.image = image;
    }
}
