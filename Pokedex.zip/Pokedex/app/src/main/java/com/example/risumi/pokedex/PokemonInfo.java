package com.example.risumi.pokedex;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class PokemonInfo extends AppCompatActivity {

    TextView name;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pokemon_info);
        Intent intent = getIntent();
        String nama = intent.getStringExtra("nama");
        name = findViewById(R.id.Fiv);
        name.setText(nama);
    }
}
