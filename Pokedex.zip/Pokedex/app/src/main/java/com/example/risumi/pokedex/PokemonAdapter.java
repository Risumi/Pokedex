package com.example.risumi.pokedex;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class PokemonAdapter extends RecyclerView.Adapter<PokemonAdapter.PokemonViewHolder> {

    LayoutInflater mInflater;
    ArrayList<Pokemon> pokemonArrayList;
    Context _context;
    Pokemon current;


    public PokemonAdapter(Context _context, ArrayList<Pokemon> pokemonArrayList ) {
        this.mInflater = LayoutInflater.from(_context);
        this.pokemonArrayList = pokemonArrayList;
        this._context = _context;
    }

    public void filterList(ArrayList filteredPokemon){
        pokemonArrayList = filteredPokemon;
        notifyDataSetChanged();
    }

    class PokemonViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener{
        TextView PokemonName;
        TextView PokemonType;
        ImageView PokemonImage;
        PokemonAdapter mAdapter;

        public PokemonViewHolder(View itemView, PokemonAdapter adapter) {
            super(itemView);
            PokemonName = itemView.findViewById(R.id.Name);
            PokemonType = itemView.findViewById(R.id.Type);
            PokemonImage = itemView.findViewById(R.id.Image);
            itemView.setOnClickListener(this);
            this.mAdapter = adapter;
        }

        @Override
        public void onClick(View view) {
//            Intent PokeIntent = new Intent(_context, PokemonInfo.class);
//            Bundle bundle = new Bundle();
//            PokeIntent.putExtra("nama",PokemonName.getText().toString());
//            _context.startActivities(new Intent[]{PokeIntent});
            Intent intent = new Intent(_context, WSActivity.class);
            _context.startActivity(intent);
            Log.d("click","yay !");
        }
    }

    @Override
    public PokemonViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = mInflater.inflate(R.layout.card,parent,false);
        return new PokemonViewHolder(itemView,this);
    }

    @Override
    public void onBindViewHolder(PokemonViewHolder holder, int position) {
        current = pokemonArrayList.get(position);
//        holder.PokemonImage.setImageResource(current.image);
        Picasso.get().load(current.imageURL).into(holder.PokemonImage);
        holder.PokemonName.setText(current.name);
        holder.PokemonType.setText(current.type);
//        if(current.type.equalsIgnoreCase("Grass")){
//            holder.PokemonType.setTextColor(Color.GREEN);
//        }else if (current.type.equalsIgnoreCase("Water")){
//            holder.PokemonType.setTextColor(Color.BLUE);
//        }else if (current.type.equalsIgnoreCase("Fire")){
//            holder.PokemonType.setTextColor(Color.RED);
//        }
    }


    @Override
    public int getItemCount() {
        return pokemonArrayList.size();
    }
}
